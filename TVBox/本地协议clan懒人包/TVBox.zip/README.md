# 2. TV'Box
* TV'Box｜APP
  + Github：[TVBoxOSC](https://github.com/CatVodTVOfficial/TVBoxOSC)
  + 测试版APK下载：
	+ 好心的大佬，提供已签名可安装的"最新测试版APK" (实时更新)
	+ [o0HalfLife0o大佬 Github](https://github.com/o0HalfLife0o/TVBoxOSC)：有下载安装成功的记得帮大佬按右上角的star星星
	+ [o0HalfLife0o大佬 TG频道](https://t.me/TVBoxOSC)：实时接收来自Github的"最新测试版APK"提醒，直接从TG下载。

## 配置地址 简易设定流程：
* 我的 --> 设置 --> 配置地址 (底下二选一)
	1. 请输入 https://github.com/YuanHsing/freed/raw/master/TVBox/meow.json --> 确定
	2. CH猫友免墙地址 请输入 https://freed.yuanhsing.cf/TVBox/meowcf.json --> 确定

## 切换数据源
* 我的 --> 设置 --> 首页数据源

## 本地协议clan
* [本地协议clan懒人包](https://github.com/YuanHsing/freed/tree/master/TVBox/%E6%9C%AC%E5%9C%B0%E5%8D%8F%E8%AE%AEclan%E6%87%92%E4%BA%BA%E5%8C%85)
下载zip后解压到SD卡根目录
本地协议clan地址:     clan://localhost/TVBox/0708local.json     
自用在线地址:         https://chtio.net/TVBox/0708.json        